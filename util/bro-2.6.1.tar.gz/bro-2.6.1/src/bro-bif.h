
#ifndef BRO_BIF_H
#define BRO_BIF_H

// Headers to include by generated BiF code.
#include "analyzer/Analyzer.h"
#include "Conn.h"
#include "NetVar.h"
#include "Event.h"

#endif
