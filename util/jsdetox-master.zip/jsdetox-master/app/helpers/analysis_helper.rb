# Helper methods defined here can be accessed in any controller or view in the application

JSDetoxWeb.helpers do
  # def simple_helper_method
  #  ...
  # end
end
