class InitDatabase < Sequel::Migration
	def up
	end

	def down
	end
end
