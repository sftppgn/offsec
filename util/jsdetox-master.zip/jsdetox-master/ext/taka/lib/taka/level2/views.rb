require 'taka/level2/views/document_view.rb'

Taka::DOM::HTML::Document.send(:include, Taka::DocumentView)