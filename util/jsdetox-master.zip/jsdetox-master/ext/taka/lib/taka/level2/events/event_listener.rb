module Taka
  module EventListener
    def handleEvent(event)
    end
  end
end