module Taka
  module DocumentView
    attr_accessor :defaultView
  end
end