module Taka
  module DOM
    module HTML
      module IsIndexElement
        include FieldSetElement
      end
    end
  end
end
