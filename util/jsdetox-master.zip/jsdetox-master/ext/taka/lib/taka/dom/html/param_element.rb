module Taka
  module DOM
    module HTML
      module ParamElement
        def name
          self['name']
        end

        def type
          self['type']
        end
      end
    end
  end
end
