module Taka
  module DOM
    module HTML
      module LegendElement
        include FieldSetElement
      end
    end
  end
end
