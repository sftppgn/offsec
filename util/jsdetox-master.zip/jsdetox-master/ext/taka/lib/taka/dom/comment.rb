module Taka
  module DOM
    module Comment
      def attributes
        nil
      end
    end
  end
end
