module Taka
  module DOM
    module HTML
      module UListElement
        def type
          self['type']
        end
      end
    end
  end
end
