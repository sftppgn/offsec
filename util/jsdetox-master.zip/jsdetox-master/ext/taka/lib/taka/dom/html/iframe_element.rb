module Taka
  module DOM
    module HTML
      module IFrameElement
        def name
          self['name']
        end
      end
    end
  end
end
