module Taka
  module DOM
    module EntityReference
      def attributes
        nil
      end
    end
  end
end
