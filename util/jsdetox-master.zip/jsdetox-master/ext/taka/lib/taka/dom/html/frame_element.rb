module Taka
  module DOM
    module HTML
      module FrameElement
        def name
          self['name']
        end
      end
    end
  end
end
