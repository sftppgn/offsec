module RKelly
  VERSION = '0.0.5'
end
