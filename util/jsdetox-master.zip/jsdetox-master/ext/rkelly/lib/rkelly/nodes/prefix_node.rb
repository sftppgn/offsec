module RKelly
  module Nodes
    class PrefixNode < PostfixNode
    end
  end
end
