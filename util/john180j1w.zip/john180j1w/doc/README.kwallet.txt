Cracking KWallet files
======================

1. Run kwallet2john on .kwl file(s).

E.g. $ ../run/kwallet2john <name>.kwl > hash

2. Run john on the output of kwallet2john.

E.g. $ ../run/john hash

3. Wait for the password to get cracked.
