Cracking Apple Disk Images (DMG)
================================

1. Run dmg2john on .dmg file(s).

E.g. $ ../run/dmg2john test.dmg > hash

2. Run john on the output of dmg2john.

E.g. $ ../run/john hash

3. Wait for the password to get cracked.

You can use the "dmg-opencl" format if you have a GPU
for faster cracking.
