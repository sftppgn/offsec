Cracking KeyStore files
======================

1. Run keystore2john on .jks file(s).

E.g. $ ../run/keystore2john <name>.jks > hash

2. Run john on the output of keystore2john.

E.g. $ ../run/john hash

3. Wait for the password to get cracked.
