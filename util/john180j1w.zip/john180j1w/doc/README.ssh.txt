Cracking password protected ssh private keys
============================================

JtR-jumbo has two formats (plug-ins) which support cracking
password protected ssh private keys, "ssh" and "ssh-ng".

ssh-ng is newer, faster but highly experimental format which
can generate false positives. Use it at your own risk.

1. Build JtR-jumbo

2. Run either of the following steps,

   a. Run ssh2john on SSH private key file(s) *OR*

   b. Run sshng2john.py on SSH private key file(s)

3. Run john on the output of step 2.
