Building JtR-jumbo on FreeBSD
=============================

If you want to build "krb5-18_fmt.c" on FreeBSD then install "security/krb5"
from ports.
