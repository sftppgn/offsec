This is a 32-bit Windows build of John the Ripper 1.8.0-jumbo-1, with
OpenMP enabled and requiring a CPU with at least SSSE3 (although some
formats will also work on SSE2), which means Intel Core 2 or newer (or
similarly non-ancient AMD CPU).  It should also run on 64-bit Windows
(albeit suboptimally).
